package com.cg.hotel.service;

import com.cg.hotel.dto.EmpProject;
import com.cg.hotel.exception.HotelException;

public interface EmpService {

	public boolean login()throws HotelException;
	
	public boolean login1()throws HotelException;
}
