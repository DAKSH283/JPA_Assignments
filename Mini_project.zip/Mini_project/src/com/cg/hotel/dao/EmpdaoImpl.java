package com.cg.hotel.dao;

import java.io.Console;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

import com.cg.hotel.dto.EmpProject;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.util.DBUtil;


public class EmpdaoImpl implements Empdao {
	private static Connection con;
	 String userdbName;
	 String userdbPsw;
//	Logger logger;
	private String qry;
	
	public EmpdaoImpl()
	{
		
	con = DBUtil.getConnect();
	
//	logger =MyLogger.getLogger();
	}

			
			
	@Override
	public boolean login1() throws HotelException {
		Scanner input = new Scanner(System.in);
		 Console console = System.console();

	   System.out.println("Enter credential for User admin:");
	   System.out.println("username: ");
	   String uname = input.next();

	   System.out.println("password: ");
	   String pwd = input.next();
	   
	   
	   try{
			String query="select * from admin where uname = ? and pwd = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, uname);
			pst.setString(2, pwd);
			
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				 userdbName = rs.getString("uname");
				 userdbPsw = rs.getString("pwd");
              
			}
	   }
	   catch(Exception e){
			throw new HotelException(e.getMessage());
	   }
           
				if(uname.equals(userdbName) && pwd.equals(userdbPsw))
				{
							
				System.out.println("valid");
				return true;
         }	
				
				
			
			else 
			{    
			
				System.out.println("Invalid User Name and Password");
				return false;
				  
	  }  

		}   
	
	





	@Override
	public boolean login() throws HotelException {
		Scanner input = new Scanner(System.in);
		 Console console = System.console();
		
	   System.out.println("Enter credential for User user:");
	   System.out.println("username: ");
	   String uname = input.next();

	   System.out.println("password: ");
	   String pwd = input.next();
	   
	   
	   try{
			String query="select * from user_u where uname = ? and pwd = ?";
			PreparedStatement pst = con.prepareStatement(query);
			pst.setString(1, uname);
			pst.setString(2, pwd);
			ResultSet rs = pst.executeQuery();
			if(rs.next()){
				 userdbName = rs.getString("uname");

				 userdbPsw = rs.getString("pwd");
              
			}
	   }
	   catch(Exception e){
			throw new HotelException(e.getMessage());
	   }
            
				if(uname.equals(userdbName) && pwd.equals(userdbPsw))
				{
					
				System.out.println("valid");
				return true;
          }	
				
			else 
			{    
			
				System.out.println("Invalid User Name and Password");
				return false;
				  
	  }  

		}   
	
	}



