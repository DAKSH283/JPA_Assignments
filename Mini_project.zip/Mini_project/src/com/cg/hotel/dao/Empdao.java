package com.cg.hotel.dao;

import java.sql.Connection;

import com.cg.hotel.dto.EmpProject;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.util.DBUtil;

public interface Empdao {
public boolean login() throws HotelException;
public boolean login1() throws HotelException;
}
