package com.cg.hotel.dao;

import java.sql.Connection;



import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;



import java.util.ArrayList;




import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.util.DBUtil;


public class HotelDaoImpl implements HotelDao{

	private static Connection con;
//	Logger logger;
	private String qry;
	public HotelDaoImpl()
	{
		
	con = DBUtil.getConnect();
	
//	logger =MyLogger.getLogger();
	}
	//to return current empId i.e. sequence current value
	public int getHotelId()throws HotelException
	{
//	logger.info("In get EmployeId");	
	int cust_id = 0;
	String qry = "select tid_seq.CURRVAL from dual";
	try {
	Statement stmt = con.createStatement();
	ResultSet rs = stmt.executeQuery(qry);
	if(rs.next())
	{
	cust_id= rs.getInt(1);
//	logger.info("getEmployeeId with id"+id);
	}
	} 
	catch (SQLException e) 
	{
	throw new HotelException(e.getMessage());
	}

//	logger.info("completed get EmployeeId");
	return cust_id;
	}
	///////////////////////
@Override
public int addHotel(Hotel hel) throws HotelException {
	// TODO Auto-generated method stub
//	logger.info("In add Employee");
//	logger.info("Input is:"+emp);
	
	int cust_id = 0;
	String qry = "insert into hotel values(tid_seq.NEXTVAL,?,?,?,?)";
	String name = hel.getCust_name();
	String phone = hel.getCust_phone();
	String address=hel.getCust_address();
	int room_no=hel.getRoom_no();
	try
	{
	PreparedStatement pstmt = con.prepareStatement(qry);
	pstmt.setString(1,name);
	pstmt.setString(2,phone);
	pstmt.setString(3,address);
    pstmt.setInt(4,room_no);
	int row = pstmt.executeUpdate();
	if(row > 0)
	{
 cust_id = getHotelId();
//	logger.info("inserted succesfully id is "+id);
     }
	else
	throw new HotelException("Unable to insert"+hel);
	}
	catch(SQLException e)
	{
//		logger.error(e.getMessage());
	throw new HotelException(e.getMessage());
	}
	return cust_id;
}
@Override
public Hotel getCustByName(String Cust_name) throws HotelException {
	Hotel hel = null;
	String qry = "select * from hotel where Cust_name=?";
	try
	{
	PreparedStatement pstmt = con.prepareStatement(qry);
	pstmt.setString(1,Cust_name);
	ResultSet rs = pstmt.executeQuery();
	if(rs.next())
	{
	String Cust_id = rs.getString(1);
	String name = rs.getString(2);
	String phone = rs.getString(3);
	String address=rs.getString(4);
	int room_no=rs.getInt(5);
	hel = new Hotel(Cust_id,name,phone,address,room_no);
	}
	else 
	throw new HotelException("Customer with name "+Cust_name+" not found");
	}catch(SQLException e)
	{
	throw new HotelException(e.getMessage());
	}
	return hel;
	}
@Override
public Hotel removeCustName(String Cust_name) throws HotelException {
	Hotel hel = null;
	String qry = "DELETE  FROM Hotel where Cust_name=?";
	try{
	PreparedStatement pstmt = con.prepareStatement(qry);
	pstmt.setString(1,Cust_name);
	int row = pstmt.executeUpdate();
	if(row > 0)
	{
	System.out.println(" Booking Deleted  with name "+Cust_name);
	}
	else if(hel== null)
	{
	throw new HotelException("Booking name "+Cust_name+"not found");
	}
	}
	catch(SQLException e)
	{
	throw new HotelException(e.getMessage());
	}
	return hel;
	}
@Override
public ArrayList<Hotel> getAllCustomer() throws HotelException {
	ArrayList<Hotel>list=new ArrayList<Hotel>();
	String qry="SELECT * FROM Hotel";
	try
	{
		Statement stmt=con.createStatement();
		ResultSet rs =stmt.executeQuery(qry);
		while(rs.next())
		{
			String Cust_id =rs.getString(1);
			String Cust_name=rs.getString(2);
			String Cust_phone=rs.getString(3);
			String Cust_address=rs.getString(4);
			int room_no=rs.getInt(5);
		Hotel hel = new Hotel(Cust_id,Cust_name,Cust_phone,Cust_address,room_no);
			list.add(hel);
			
			
			
			
		}
	}	
	catch(SQLException e)
	{
	throw new HotelException(e.getMessage());
	}
	
return list;
}

}





