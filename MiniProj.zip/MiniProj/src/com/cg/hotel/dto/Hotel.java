package com.cg.hotel.dto;

public class Hotel {
	   
		
		private String Cust_name;
		private  String Cust_phone;
		private  String Cust_address;
		private  int room_no;
		 private String Cust_id;
		 public String getCust_id() {
				return Cust_id;
			}
			public void setCust_id(String cust_id) {
				Cust_id = cust_id;
			}
		public String getCust_name() {
			return Cust_name;
		}
		public void setCust_name(String cust_name) {
			Cust_name = cust_name;
		}
		public String getCust_phone() {
			return Cust_phone;
		}
		public void setCust_phone(String cust_phone) {
			Cust_phone = cust_phone;
		}
		public String getCust_address() {
			return Cust_address;
		}
		public void setCust_address(String cust_address) {
			Cust_address = cust_address;
		}
		public int getRoom_no() {
			return room_no;
		}
		public void setRoom_no(int room_no) {
			this.room_no = room_no;
		}
		@Override
		public String toString() {
			return "Hotel [Cust_id=" + Cust_id + ", Cust_name=" + Cust_name
					+ ", Cust_phone=" + Cust_phone + ", Cust_address="
					+ Cust_address + ", room_no=" + room_no + "]";
		}
		public Hotel(String cust_id, String cust_name, String cust_phone,
				String cust_address, int room_no) {
			super();
			Cust_id = cust_id;
			Cust_name = cust_name;
			Cust_phone = cust_phone;
			Cust_address = cust_address;
			this.room_no = room_no;
		}
		public Hotel() {
			super();
			// TODO Auto-generated constructor stub
		}
	
		

	}


