package com.cg.hotel.pl;

import java.util.ArrayList;
import java.util.Scanner;


import com.cg.hotel.dto.Hotel;
import com.cg.hotel.exception.HotelException;
import com.cg.hotel.service.HotelService;
import com.cg.hotel.service.HotelServiceImpl;


public class MainClass {
		
	static  HotelService service =new HotelServiceImpl();
	public static void main (String[] args){
		
			int choice =0;
			try(Scanner sc =new Scanner (System.in)){
				
				do
				{
					System.out.println("Welcome to Our Hotel Book Services" );
					System.out.println("1-Book Room");
					System.out.println("2- Search  Booked Room by Name");
//					System.out.println("3- Delete Booked  Room by Name");
				System.out.println("4-View Booking Status");
					
					
			        System.out.println("Enter choice ");
			        choice =sc.nextInt();
					switch (choice ) 
					
					
					{ 
				case 1:
			
				
					Hotel hel=acceptHotelDetails();
					if(hel!=null){
								
					
				try
				{
					
				int cust_id = service.addHotel(hel);
				System.out.println("Inserted and Cust_id = "+cust_id);
				}
				
				catch(HotelException e)
				{
					System.out.println(e.getMessage());
				}
				
				
			}
					break;
				case 2:
					System.out.println("Enter Cust_Name");
					String Cust_name=sc.next();
					Hotel hel1 = new Hotel();
				
					try
					{
						
						hel1 = service.getCustByName(Cust_name);
						System.out.println(hel1);
				
					}
					
					catch(HotelException e)
					{
						
					System.out.println(e.getMessage());
					}
					break;
				case 3:
					System.out.println("Enter name");
					String Cust_name1 =sc.next();
					Hotel hel2 = new Hotel();
				
					try
					{
						
					hel2 = service. removeCustName(Cust_name1);
				
					}
					
					catch(HotelException e)
					{
						
					System.out.println(e.getMessage());
					}
					break;
				case 4:
					try{
						ArrayList<Hotel> list=service.getAllCustomer();
						System.out.println("All Customer:" +list);
						
					}
					catch(HotelException e)
					{
						
					System.out.println(e.getMessage());
					}
					break;
					
					
					}
					System.out.println("Do u want to continue 1 - yes 0-No");
					choice = sc.nextInt();
				
				}
				
					
				
				while(choice!=0);
				
				}
			}


	public static Hotel acceptHotelDetails()
	{
		Hotel hel = null;
		Scanner sc = new Scanner(System.in);
		while(true)
		{
			System.out.println("Enter name::");
			String name = sc.next();
			if(!service.validateName(name))
			{
				continue;
			}
			else
			{
				while(true)
				{
					System.out.println("Enter phone_no::");
					String phone_no= sc.next();
					if(!service.validatePhoneno(phone_no))
					{
						continue;
					}
					else
					{
						while(true)
						{
							System.out.println("Enter Room No.:");
							int room_no;
							
								 room_no = sc.nextInt();
							
							
							if(!service.validateRoom_no(room_no))
							{
								continue;
							}
							else
							{
						
						
						System.out.println("Enter address::");
						String address = sc.next();
						if(!service.validateAddress(address))
							
						
						{
							hel = new Hotel();
							hel.setCust_name(name);
							hel.setCust_address(address);
							hel.setCust_phone(phone_no);
							hel.setRoom_no(room_no);
							break;
	
					}
						System.out.println();
				}
			}
			return hel;
		}
					}
				}
		
		}
	}
}

		



				
